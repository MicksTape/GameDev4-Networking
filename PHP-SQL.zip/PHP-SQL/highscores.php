<?php
// Connect to the database
include("connect.inc");

if (isset($_GET['session_id'])) { // Check if session ID is in the URL
    $sid = htmlspecialchars($_GET['session_id']); // Sanitize session ID from URL
    session_id($sid); // Set session ID for this session to the one from the URL
}

// Start or resume the session
session_start();
?>

<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333333;
            margin-bottom: 20px;
        }

        h3 {
            text-align: center;
            color: #666666;
            margin-bottom: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            border-radius: 5px;
            overflow: hidden;
        }

        th, td {
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
            color: #333333;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .winner {
            background-color: #b3e6b3;
            color: #006600;
        }

        .loser {
            background-color: #ffcccc;
            color: #990000;
        }

        .draw {
            background-color: #e6e6e6;
            color: #666666;
        }
    </style>
    <style>
        /* Additional styles */

        /* Override table styles */
        table {
            box-shadow: none;
        }

        th {
            background-color: #333333;
            color: #ffffff;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:nth-child(odd) {
            background-color: #e6e6e6;
        }

        .winner {
            background-color: #b3e6b3;
            color: #006600;
        }

        .loser {
            background-color: #ffcccc;
            color: #990000;
        }

        .draw {
            background-color: #e6e6e6;
            color: #666666;
        }
    </style>
</head>

<body>
<div class="container">
    <h1>Highscores</h1>
    <h3>Top 5 Players</h3>

    <table>
        <tr>
            <th>Name</th>
            <th>Score</th>
        </tr>

        <?php
        // Retrieve top 5 players' scores
        $scoreQuery = "SELECT * FROM users ORDER BY score DESC LIMIT 5";
        $scoreResult = mysqli_query($db, $scoreQuery) or die('Error querying database.');

        // Display top 5 players' scores
        // Check if session id exists
        if (isset($_SESSION['session_id']) && filter_var($_SESSION['session_id'], FILTER_SANITIZE_STRING)) {
            $count = 0;
            while ($row = mysqli_fetch_array($scoreResult)) {
                $count++;
                echo "<tr" . ($count % 2 == 0 ? " style='background-color: #e6e6e6;'" : "") . ">";
                echo "<td>" . $row['username'] . "</td>";
                echo "<td>" . $row['score'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<color=red>You are not logged in!</color>";
        }
        ?>

    </table>

    <h3>Last Played Games</h3>

    <table>
        <tr>
            <th>Player 1</th>
            <th>Score</th>
            <th>VS</th>
            <th>Player 2</th>
            <th>Score</th>
            <th>Date</th>
        </tr>
        <?php
        // Retrieve last 10 played games
        $gamesQuery = "SELECT * FROM scores ORDER BY date DESC LIMIT 10";
        $gamesResult = mysqli_query($db, $gamesQuery) or die('Error querying database.');

        // Display last 10 played games with appropriate colors
        if (isset($_SESSION['session_id']) && filter_var($_SESSION['session_id'], FILTER_SANITIZE_STRING)) {
            $count = 0;
            while ($row = mysqli_fetch_array($gamesResult)) {
                $count++;
                $scorePlayer1 = $row['score_player1'];
                $scorePlayer2 = $row['score_player2'];
                $usernamePlayer1 = $row['username_player1'];
                $usernamePlayer2 = $row['username_player2'];
                $date = $row['date'];

                echo "<tr" . ($count % 2 == 0 ? " style='background-color: #e6e6e6;'" : "") . ">";

                if ($scorePlayer1 > $scorePlayer2) {
                    echo "<td class='winner'>$usernamePlayer1</td>";
                    echo "<td class='winner'>$scorePlayer1</td>";
                    echo "<td>VS</td>";
                    echo "<td class='loser'>$usernamePlayer2</td>";
                    echo "<td class='loser'>$scorePlayer2</td>";
                    echo "<td>$date</td>";
                } elseif ($scorePlayer1 < $scorePlayer2) {
                    echo "<td class='loser'>$usernamePlayer1</td>";
                    echo "<td class='loser'>$scorePlayer1</td>";
                    echo "<td>VS</td>";
                    echo "<td class='winner'>$usernamePlayer2</td>";
                    echo "<td class='winner'>$scorePlayer2</td>";
                    echo "<td>$date</td>";
                } else {
                    echo "<td class='draw'>$usernamePlayer1</td>";
                    echo "<td class='draw'>$scorePlayer1</td>";
                    echo "<td>VS</td>";
                    echo "<td class='draw'>$usernamePlayer2</td>";
                    echo "<td class='draw'>$scorePlayer2</td>";
                    echo "<td>$date</td>";
                }

                echo "</tr>";
            }
        } else {
            echo "<color=red>You are not logged in!</color>";
        }
        ?>

    </table>
</div>

<?php
// Close the database connection
mysqli_close($db);
?>
</body>
</html>
