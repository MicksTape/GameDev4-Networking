<?php
// Connect to database
include("connect.inc");

session_start();

$_SESSION["username"] = "gertje";
echo "<br>";
echo $_SESSION["username"];
if (!isset($_SESSION["username"])) {
    echo "<br>";
    echo "You are not logged in!";
} else {
    echo "<br>";
    echo "You are logged in!"; 

    $_SESSION["session_id"] = session_id();
    echo "<br>";
    echo "<strong>Session ID:</strong> {$_SESSION["session_id"]}";
}
?>


