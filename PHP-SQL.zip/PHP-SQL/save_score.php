<?php
// Connect to database
include("connect.inc");

if (isset($_GET['session_id'])) { // Check if session ID is in the URL
    $sid = htmlspecialchars($_GET['session_id']); // Sanitize session ID from URL
    session_id($sid); // Set session ID for this session to the one from the URL
}

session_start();

// Variables
$userID = $_POST["userID"];
$userScore = $_POST["userScore"];

$query = "SELECT id, score FROM users WHERE id = '$userID' LIMIT 1";
$result = mysqli_query($db, $query) or die("Error querying database.");

// Check if session id exists
if (isset($_SESSION["session_id"])) {
	// Check if database has users
	if (mysqli_num_rows($result) > 0) { 

		// Update in database
		$updateScoreQuery = "UPDATE users SET score = '$userScore' WHERE id = $userID";
		$updateScoreResult = mysqli_query($db, $updateScoreQuery) or die("Error querying database.");

		if (mysqli_query($db, $updateScoreQuery)) {
			echo $row["score"];
		} else {
		echo "Error: " . $updateScoreQuery . "<br>" . mysqli_error($db);
		}
	}
} else {
	echo "<color=red>Server id does not exist.</color>";
}

//Step 4
mysqli_close($db);

?>