<?php
// Connect to database
include("connect.inc");

if (isset($_GET['session_id'])) { // Check if session ID is in the URL
    $sid = htmlspecialchars($_GET['session_id']); // Sanitize session ID from URL
    session_id($sid); // Set session ID for this session to the one from the URL
}

session_start();

// Variables
$registerUser = $_POST["registerUser"];
$registerPass = $_POST["registerPass"];
$registerPassRepeat = $_POST["registerPassRepeat"];

// Sanitize input
$registerUser = mysqli_real_escape_string($db, $registerUser);
$registerPass = mysqli_real_escape_string($db, $registerPass);
$registerPassRepeat = mysqli_real_escape_string($db, $registerPassRepeat);

$query = "SELECT id, username FROM users WHERE username = ? LIMIT 1";
$stmt = mysqli_prepare($db, $query);
mysqli_stmt_bind_param($stmt, "s", $registerUser);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Check if session id exists
if (isset($_SESSION["session_id"])) {
    // Check if database has users
    if (mysqli_num_rows($result) > 0) { 
        // Tell user that name is already taken
        echo "<color=red>Username is already taken.</color>";
    } else {
        // Check if username is a certain number of characters
        if (strlen($registerUser) >= 4 && strlen($registerUser) <= 10) {
            // Check if password is a certain number of characters
            if (strlen($registerPass) >= 4) {
                // Check if passwords match and username is not empty
                if ($registerPass == $registerPassRepeat && !empty($registerUser)) {
                    // Salt and hash password
                    $salt = "328yurfhu42fhurg7df";
                    $hashedPass = password_hash($registerPass.$salt, PASSWORD_DEFAULT);

                    // Insert the username and password into the database
                    $createUserQuery = "INSERT INTO users (username, password, score) VALUES (?, ?, 0)";
                    $stmt = mysqli_prepare($db, $createUserQuery);
                    mysqli_stmt_bind_param($stmt, "ss", $registerUser, $hashedPass);
                    if (mysqli_stmt_execute($stmt)) {
                        echo "<color=green>New user created successfully. Go back to login.</color>";
                        echo $row["id"];
                    } else {
                        echo "Error: " . $createUserQuery . "<br>" . mysqli_error($db);
                    }
                } else {
                    echo "<color=red>Passwords don't match.</color>";
                }
            } else {
                echo "<color=red>Password has to be at least 4 characters long.</color>";
            }
        } else {
            echo "<color=red>Username and password has to be at least 4 and max. 10 characters long.</color>";
        }
    }
} else {
    echo "<color=red>Unauthorized session id!</color>";
}
// Close database connection
mysqli_close($db);
?>
