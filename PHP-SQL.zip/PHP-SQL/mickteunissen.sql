-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 16, 2023 at 12:46 PM
-- Server version: 10.6.12-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mickteunissen`
--

-- --------------------------------------------------------

--
-- Table structure for table `scores`
--

CREATE TABLE `scores` (
  `id` int(4) NOT NULL,
  `server_id` int(255) DEFAULT NULL,
  `username_player1` varchar(10) NOT NULL,
  `score_player1` int(255) DEFAULT NULL,
  `username_player2` varchar(10) NOT NULL,
  `score_player2` int(255) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `scores`
--

INSERT INTO `scores` (`id`, `server_id`, `username_player1`, `score_player1`, `username_player2`, `score_player2`, `date`) VALUES
(8, NULL, 'samson', 2, 'gertje', 1, '2023-06-11 20:37:01'),
(9, NULL, 'samson', 2, 'gertje', 1, '2023-06-11 20:53:03'),
(10, NULL, 'samson', 1, 'gertje', 3, '2023-06-11 21:40:35'),
(11, NULL, 'samson', 1, 'gertje', 1, '2023-06-11 21:42:07'),
(12, NULL, 'samson', 1, 'gertje', 2, '2023-06-11 21:46:28'),
(13, NULL, 'gertje', 1, 'samson', 1, '2023-06-11 22:02:38'),
(14, NULL, 'gertje', 1, 'samson', 3, '2023-06-14 20:31:08'),
(15, NULL, 'gertje', 2, 'samson', 1, '2023-06-15 21:44:59'),
(16, NULL, 'samson', 1, 'gertje', 1, '2023-06-16 09:46:05'),
(17, NULL, 'gertje', 2, 'samson', 1, '2023-06-16 09:51:51'),
(18, NULL, 'gertje', 2, 'samson', 1, '2023-06-16 10:37:14'),
(19, NULL, 'gertje', 1, 'samson', 4, '2023-06-16 10:46:10'),
(21, NULL, 'gertje', 2, 'test', 1, '2023-06-16 11:22:36'),
(22, NULL, 'henk', 1, 'test2', 2, '2023-06-16 11:52:54'),
(23, NULL, 'test', 5, 'henk', 4, '2023-06-16 12:12:47');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(4) NOT NULL,
  `username` varchar(10) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `score` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `score`) VALUES
(1, 'samson', NULL, '$2y$10$MICfYjyeFHOEiSpkkjj19.18UPKFHQuYVsxyhn0AqMbn7mmgBs2vW', 27),
(2, 'samson1', NULL, '$2y$10$IxRwQQlNsivA4KQ0dI/oD.TjZUP3Hf8Sm7QG8c91VJpSibk3CbNfO', 0),
(3, 'gertje', NULL, '$2y$10$WHq4mwLnoiEz7f459.F3GOH2EUvV1S5W85a2OLBWDGjhEFtkbej/a', 29),
(4, 'test', NULL, '$2y$10$PRppmP4b4iyht.60YIRUXeG0R0JjxllMWoKJ3CGeIIVC1mycBxtQq', 9),
(5, 'henk', NULL, '$2y$10$SDNqmSnJXE.6rhURoaetXOeoajukLRIBK3OyQjznkLXFzbFU0tqwu', 5),
(6, 'jaapie', NULL, '$2y$10$QUaMeHXgv4R2fiWPxGpIdeSFMYCRp0rkXuPP2.RmztSqPyQe4l0g6', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `scores`
--
ALTER TABLE `scores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `scores`
--
ALTER TABLE `scores`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
