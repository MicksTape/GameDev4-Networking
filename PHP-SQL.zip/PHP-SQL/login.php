<?php
// Connect to database
include("connect.inc");

if (isset($_GET['session_id'])) { // Check if session ID is in the URL
    $sid = htmlspecialchars($_GET['session_id']); // Sanitize session ID from URL
    session_id($sid); // Set session ID for this session to the one from the URL
}

session_start();

// Variables
$loginUser = $_POST["loginUser"];
$loginPass = $_POST["loginPass"];

// Sanitize input
$loginUser = mysqli_real_escape_string($db, $loginUser);
$loginPass = mysqli_real_escape_string($db, $loginPass);

$query = "SELECT id, password FROM users WHERE username = ? LIMIT 1";
$stmt = mysqli_prepare($db, $query);
mysqli_stmt_bind_param($stmt, "s", $loginUser);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Check if session id exists
if (isset($_SESSION["session_id"])) {
    // Check if database has users
    if (mysqli_num_rows($result) > 0) {
        // Output data of each row
        while ($row = mysqli_fetch_assoc($result)) {
            // Check if username is a certain number of characters
            if (strlen($loginUser) >= 4 && strlen($loginUser) <= 10) {
                // If password submitted matches the password in the database
                $salt = "328yurfhu42fhurg7df";
                if (password_verify($loginPass.$salt, $row["password"])) {
                    echo $row["id"];
                    // Output session id as result
                } else {
                    echo "<color=red>Wrong credentials.</color>";
                }
            } else {
                echo "<color=red>Username does not exist.</color>";
            }
        }
    } else {
        echo "<color=red>Username does not exist.</color>";
    }
} else {
    echo "<color=red>Unauthorized session id!</color>";
}

// Close database connection
mysqli_close($db);
?>
