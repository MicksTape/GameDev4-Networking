<?php
// Connect to database
include("connect.inc");

session_start();

?>


<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            max-width: 400px;
            border: 1px solid #ddd;
            padding: 30px;
            border-radius: 5px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h1 {
            margin-bottom: 20px;
            text-align: center;
            color: #333333;
        }

        p {
            margin-bottom: 20px;
            color: #666666;
            text-align: center;
        }

        form {
            text-align: left;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 10px;
            color: #333333;
        }

        input[type="text"],
        input[type="password"] {
            margin-bottom: 20px;
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button[type="submit"] {
            padding: 10px 20px;
            background-color: #333333;
            color: #ffffff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .error {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>

<body>
<div class="container">
    <h1>Edit your account</h1>
    <?php
    
    $id = $_GET['id'];
    $username = $_GET['username'];
    $password = $_GET['password'];
    $session_id = $_SESSION['session_id'];
    
    // Check if session id exists
    if (isset($_SESSION['session_id']) && filter_var($_SESSION['session_id'], FILTER_VALIDATE_INT)) {
        // Check if id is int, and if username and password do not contain spaces
        if (filter_var($id, FILTER_VALIDATE_INT) && strpos($username, ' ') === false && strpos($password, ' ') === false) {

            $query = "SELECT * FROM users WHERE id = '$id' AND username = '$username' AND password = '$password' LIMIT 1";
            $result = mysqli_query($db, $query) or die("Error querying database.");

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) { // Only show associative keys, no numeric keys
                    ?>
                    <p>You are logged in as <strong><?php echo $_GET['username']; ?></strong></p>
                    <form action="" method="post">
                        <label for="inputUsername">Username:</label>
                        <input type="text" minlength="4" maxlength="10" name="inputUsername"
                            value="<?php echo $username ?>">
                        <button type="submit" name="update-username">Change username</button>
                        <br><br>
                        <label for="inputPassword">Password:</label>
                        <input type="password" minlength="4" maxlength="9" name="inputPassword" value="********">
                        <input type="password" minlength="4" maxlength="9" name="inputPasswordRepeat"
                            placeholder="Repeat Password...">
                        <button type="submit" name="update-password">Change password</button>
                    </form>
                    <?php

                    // When clicked on change username
                    if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['update-username'])) {

                        $inputUsername = $_POST['inputUsername'];
                        $getUsernameQuery = "SELECT username FROM users WHERE username = '$inputUsername' LIMIT 1";
                        $usernameResult = mysqli_query($db, $getUsernameQuery) or die("Error querying database.");

                        // Check if given input is not empty
                        if (strlen($_POST['inputUsername']) >= 4 && strlen($_POST['inputUsername']) <= 10) {
                            // Check if database has user with username
                            if (mysqli_num_rows($usernameResult) > 0) {
                                // If username is the same as current username
                                if ($inputUsername == $username) {
                                    echo "<span class='error'>Username is the same as your current username!</span>";
                                } else {
                                    // If username is claimed by someone else
                                    echo "<span class='error'>Username already taken by someone else!</span>";
                                }
                            } else {
                                // Update in database
                                $updateUsernameQuery = "UPDATE users SET username = '$inputUsername' WHERE id = $id";
                                $updateUsernameResult = mysqli_query($db, $updateUsernameQuery) or die("Error querying database.");
                                echo("<script>alert('Username changed successfully!')</script>");
                                echo("<script>window.location = 'edit_profile.php?id=$id&username=$inputUsername&password=$password';</script>");

                            }
                        } else {
                            // If given input is empty
                            echo "<span class='error'>No username given!</span>";
                        }
                    }

                    // When clicked on change password
                    if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['update-password'])) {

                        $inputPassword = $_POST['inputPassword'];
                        $inputPasswordRepeat = $_POST['inputPasswordRepeat'];

                        // Check if given input is not empty
                        if (strlen($_POST['inputPassword']) >= 4) {
                            // If passwords match
                            if ($inputPassword == $inputPasswordRepeat) {

                                // Salt and hash password
                                $salt = "328yurfhu42fhurg7df";
                                $hashedPass = password_hash($inputPassword . $salt, PASSWORD_DEFAULT);

                                // If password is not the same as the current password
                                if (!password_verify($hashedPass, $password)) {
                                    // Update in database
                                    $updatePasswordQuery = "UPDATE users SET password = '$hashedPass' WHERE id = $id";
                                    $updatePasswordResult = mysqli_query($db, $updatePasswordQuery) or die("Error querying database.");
                                    echo("<script>alert('Password changed successfully!')</script>");
                                    echo("<script>window.location = 'edit_profile.php?id=$id&username=$username&password=$hashedPass';</script>");
                                    //echo "<span class='error'>Password changed successfully</span>";
                                } else {
                                    echo "<span class='error'>Password is the same as your current password!</span>";
                                }
                            } else {
                                echo "<span class='error'>Passwords don't match!</span>";
                            }

                        } else {
                            // If given input is empty
                            echo "<span class='error'>No password given!</span>";
                        }
                    }
                }
            } else {
                ?>
                <h1>Access denied 2</h1>
                <p>You do not have permissions to access this page.</p>
                <?php
                //echo json_encode(array('id' => 0)); // Output 0 as result
            }
        } else {
            ?>
            <h1>Access denied</h1>
            <p>You do not have permissions to access this page.</p>
            <?php
            //echo json_encode(array('id' => 0)); // Output 0 as result
        }
    } else {
       echo "<color=red>You do not have permission to access this page.</color>";
       $_SESSION["session_id"] = session_id();
       echo "<strong>Session ID:</strong> {$_SESSION["session_id"]}";
    }

    //Step 4
    mysqli_close($db);

    ?>
</div>
</body>
</html>
