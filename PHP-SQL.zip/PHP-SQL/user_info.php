<?php
// Connect to database
include("connect.inc");

session_start();

// Variables
$userID = $_POST["userID"];

$query = "SELECT id, username, password, score FROM users WHERE id = '$userID'";
$result = mysqli_query($db, $query) or die("Error querying database.");

// Check if session id exists
if (isset($_SESSION["session_id"])) {
	// Check if database has users
	if (mysqli_num_rows($result) > 0) { 

		while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) { // Only show associative keys, no numeric keys

		echo json_encode($row);
		}
	} else {
		echo "<color=red>0 results.</color>";
	}
} else {
	echo "<color=red>Server id does not exist.</color>";
}

mysqli_close($db);

?>