<?php
// Connect to database
include("connect.inc");

if (isset($_GET['session_id'])) { // Check if session ID is in the URL
    $sid = htmlspecialchars($_GET['session_id']); // Sanitize session ID from URL
    session_id($sid); // Set session ID for this session to the one from the URL
}

session_start();

// Variables
$username_p1 = $_POST["username_player1"];
$username_p2 = $_POST["username_player2"];
$score_p1 = $_POST["score_player1"];
$score_p2 = $_POST["score_player2"];

$query = "SELECT username_player1, score_player1, username_player2, score_player2, date FROM scores";
$result = mysqli_query($db, $query) or die("Error querying database.");

// Check if session id exists
if (isset($_SESSION["session_id"])) {
	// Check if points are an int value
	if (filter_var($score_p1, FILTER_VALIDATE_INT) && filter_var($score_p2, FILTER_VALIDATE_INT)) {  
		
		// Update in database
		$scores_query = "INSERT INTO scores (username_player1, score_player1, username_player2, score_player2) VALUES ('$username_p1', '$score_p1', '$username_p2', '$score_p2')";
		$scores_result = mysqli_query($db, $scores_query) or die("Error querying database.");
	}
} else {
	echo "<color=red>Server id does not exist.</color>";
}

//Step 4
mysqli_close($db);

?>